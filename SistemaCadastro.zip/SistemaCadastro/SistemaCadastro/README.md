# SistemaCadastro
Sistema de cadastro responsivo, desenvolvido em CSS, HTML e Bootstrap 4.1. 
Animações desenvolvidas com @keyframes.

## Screenshot 
Screenshots das telas, utilizando device frame do Iphone. 


![Screenshot](img/screenshot/page1.png)
![Screenshot](img/screenshot/page2.png)
![Screenshot](img/screenshot/page3.png)
![Screenshot](img/screenshot/page4.png)
